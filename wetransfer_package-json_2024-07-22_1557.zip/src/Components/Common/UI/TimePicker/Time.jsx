import React from 'react';

function Time() {
    return (
        <>
            <label className='d-block text-start'>Call Back Time</label>
            <input type="time" className='form-control input-border'/>
        </>
    );
}

export default Time
