import React from "react";

const PolicyTrackerCtn = () => {
  return <div>Policy Tracker Ctn</div>;
};

export default PolicyTrackerCtn;
