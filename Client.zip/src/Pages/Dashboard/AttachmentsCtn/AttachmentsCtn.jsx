import React from 'react'

const AttachmentsCtn = () => {
  return (
    <div>AttachmentsCtn</div>
  )
}

export default AttachmentsCtn