import React from "react";

const InboxCtn = () => {
  return <div>Inbox Ctn</div>;
};

export default InboxCtn;
