import React from "react";
import {
  Tabs,
  Avatar,
  List,
} from "rsuite";
import {
  DocumentText,
  AttachCircle,
  ShieldSecurity,
  HeartTick,
  ArrowRotateLeft,
  Sms,
  CallCalling,
  MessageText1,
} from "iconsax-react";
import PolicyDetail from "./PolicyDetail/PolicyDetail";
import AttachmentsCtn from "./AttachmentsCtn/AttachmentsCtn";
import InboxCtn from "./InboxCtn/InboxCtn";
import PolicyTrackerCtn from "./PolicyTrackerCtn/PolicyTrackerCtn";
import HistoryCtn from "./HistoryCtn/HistoryCtn";
import HealthDetailsCtn from "./HealthDetailsCtn/HealthDetailsCtn";

const Dashboard = () => {
  return (
    <>
      <section className="gw-content-body transition-ease position-relative">
        <div className="container-fluid">
          <div className="row">
            <div className="col-md-12 gw-body-col-12">
              <div className="defult-page-frame">
                <div className="gsw-tabheader-right position-absolute end-0 z-1 d-flex align-items-center gap-3">
                    <div className="gsw-header-authorinfo d-flex align-items-center gap-2">
                      <Avatar src="https://i.pravatar.cc/150?u=2" circle />
                      <div className="gsw-authorinfo-namemail">
                          <p className="gsw-userinfo-click">John Doe Calvin</p>
                          <span>john.calvin@gmail.com</span>
                        </div>
                    </div>
                    <div className="beneficiary-point m-0">
                    <List className="p-0 m-0 gap-2 d-flex align-items-center list-unstyled">
                        <List.Item className="p-0">
                          <a href="#" className="point-icon text-decoration-none text-blue d-flex align-items-center justify-content-center">
                            <Sms size="16" color="#1B84FF" variant="Bold" />
                          </a>
                        </List.Item>
                        <List.Item className="p-0">
                        <a href="#" className="point-icon text-decoration-none text-success d-flex align-items-center justify-content-center">
                            <CallCalling size="16" color="#14AC48" variant="Bold" />
                          </a>
                        </List.Item>
                        <List.Item className="p-0">
                        <a href="#" className="point-icon text-decoration-none text-purple d-flex align-items-center justify-content-center">
                            <MessageText1 size="16" color="#874BFF" variant="Bold" />
                          </a>
                        </List.Item>
                      </List>
                    </div>
                </div>
                <Tabs
                  defaultActiveKey="1"
                  appearance="subtle"
                  className="gw-pagetabs gap-0"
                >
                  <Tabs.Tab
                    eventKey="1"
                    title="Policy details"
                    icon={<DocumentText size="20" variant="Bold" />}
                  >
                    <PolicyDetail />
                  </Tabs.Tab>
                  <Tabs.Tab
                    eventKey="2"
                    title="Attachments"
                    icon={<AttachCircle size="20" variant="Bold" />}
                  >
                    <AttachmentsCtn />
                  </Tabs.Tab>
                  <Tabs.Tab
                    eventKey="3"
                    title="Inbox"
                    icon={<Sms size="20" variant="Bold" />}
                  >
                    <InboxCtn />
                  </Tabs.Tab>
                  <Tabs.Tab
                    eventKey="4"
                    title="Policy Tracker"
                    icon={<ShieldSecurity size="20" variant="Bold" />}
                  >
                    <PolicyTrackerCtn />
                  </Tabs.Tab>
                  <Tabs.Tab
                    eventKey="5"
                    title="History"
                    icon={<ArrowRotateLeft size="20" variant="Bold" />}
                  >
                    <HistoryCtn />
                  </Tabs.Tab>
                  <Tabs.Tab
                    eventKey="6"
                    title="Health details"
                    icon={<HeartTick size="20" variant="Bold" />}
                  >
                    <HealthDetailsCtn />
                  </Tabs.Tab>
                </Tabs>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Dashboard;
