import React from "react";
import {
  Button,
  ButtonToolbar,
  Form,
  Dropdown,
  Modal,
  Placeholder,
} from "rsuite";
import { Add, SearchNormal1, More } from "iconsax-react";
import PolicyDetailsTable from "../../../Components/Pages/PolicyDetails/PolicyDetailsTable";

const PolicyDetail = () => {
  const [openPolicy, setOpenPolicy] = React.useState(false);
  const addpolicyOpen = () => setOpenPolicy(true);
  const addpolicyClose = () => setOpenPolicy(false);
  return (
    <>
      {/* Policy details Conetnt start */}
      <div className="gsw-globel-filter d-flex justify-content-center justify-content-lg-between align-items-center">
        <ButtonToolbar className="gsw-globel-filter-btn">
          <Button className="btn">All | 4</Button>
          <Button className="btn">Active | 1</Button>
          <Button className="btn">Inactive | 1</Button>
          <Button className="btn">At Risk | 1</Button>
          <Button className="btn">Future | 1</Button>
        </ButtonToolbar>
        <div className="d-flex align-items-center gsw-filter-search">
          <Form>
            <Form.Group controlId="" className="form-group mb-0 w-100 d-flex">
              <Form.Control
                className="rounded-3 search-control"
                placeholder="Search"
                name="Search"
              />
              <Button className="search-btn-cont">
                <SearchNormal1 color="#667085" variant="Outline" size={16} />
              </Button>
            </Form.Group>
          </Form>
          <Button
            onClick={addpolicyOpen}
            className="btn"
            startIcon={<Add size="16" color="#fff" variant="Outline" />}
          >
            Add Policy
          </Button>
          <Dropdown
            className="exportmenu-line"
            title=""
            icon={<More size="20" color="#343434" variant="Outline" />}
            noCaret
            placement="bottomEnd"
          >
            <Dropdown.Item>Export</Dropdown.Item>
            <Dropdown.Item>Custom Data View</Dropdown.Item>
          </Dropdown>
        </div>
      </div>
      <div className="gsw-globel-table">
        <div className="table-responsive mb-3 scrollbar">
          <PolicyDetailsTable />
        </div>
      </div>
      {/* Add Policy Modal box start */}
      <Modal open={openPolicy} onClose={addpolicyClose}>
        <Modal.Header>
          <Modal.Title>Go Insurewise Life Insurance</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Placeholder.Paragraph />
        </Modal.Body>
        <Modal.Footer>
          <Button onClick={addpolicyClose} appearance="primary">
            Ok
          </Button>
          <Button onClick={addpolicyClose} appearance="subtle">
            Cancel
          </Button>
        </Modal.Footer>
      </Modal>
      {/* Add Policy Modal box End */}
      {/* Policy details Conetnt end */}
    </>
  );
};

export default PolicyDetail;
