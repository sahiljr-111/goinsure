import React from "react";

const HealthDetailsCtn = () => {
  return <div>Health Details Ctn</div>;
};

export default HealthDetailsCtn;
