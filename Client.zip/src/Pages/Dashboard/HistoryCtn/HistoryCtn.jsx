import React from "react";

const HistoryCtn = () => {
  return <div>History Ctn</div>;
};

export default HistoryCtn;
