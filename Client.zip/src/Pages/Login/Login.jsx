import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Message, useToaster } from "rsuite";
const Login = () => {
  const toaster = useToaster();
  const navigate = useNavigate();
  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
  });
  const handleChange = ({ target }) => {
    const { name, value } = target;
    setLoginData({ ...loginData, [name]: value });
  };
  const handleLoginSubmit = (e) => {
    e.preventDefault();
    navigate("/dashboard");
    toaster.push(
      <Message type={"success"} closable>
        <p className="fs-6">User Login Succesfully.</p>
      </Message>,
      { placement: "topEnd", duration: 2000 }
    );
  };
  return (
    <>
      <section className="login-section d-flex align-items-center justify-content-center">
        <div className="container">
          <div className="login-wrap">
            <h3>Login to your account</h3>
            <p>Enter your information below to log in</p>
            <form onSubmit={handleLoginSubmit}>
              <div className="form-group">
                <label className="form-label">Email</label>
                <input
                  type="email"
                  placeholder="Please Enter your Email"
                  id="email"
                  name="email"
                  value={loginData.email}
                  className="form-control"
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label className="form-label">Password</label>
                <div className="password-box position-relative">
                  <input
                    type="password"
                    placeholder="*********"
                    id="password"
                    name="password"
                    value={loginData.password}
                    onChange={handleChange}
                    className="form-control"
                    required
                  />
                  <span
                    className="iconsax pwd-show-hide"
                    icon-name="eye-slash"
                  ></span>
                </div>
                <a href="#" className="d-block forgot-pw">
                  Forgot Password?
                </a>
              </div>
              <div className="login-btns">
                <button type="submit" className="btn w-100">
                  Sign in
                </button>
              </div>
              {/* <h6>
                Don’t have an Account? <a href="#">Sign up</a>
              </h6> */}
            </form>
          </div>
        </div>
      </section>
    </>
  );
};

export default Login;
