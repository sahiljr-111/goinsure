import React, { useState } from "react";
import { Chainlink, Eye, Edit2, Trash } from "iconsax-react";
import { Button, ButtonToolbar } from "rsuite";
import ViewModal from "./ViewModal";
import EditModal from "./EditModal";
import Swal from "sweetalert2";
const PolicyDetailData = [
  {
    Id: 1,
    Verify: true,
    PolicyNumber: "GIW00982821",
    PolicyType: "Life Insurance",
    Carrier: "AIG",
    Product: "AIG Life",
    ProductType: "Level",
    Premium: 1000,
    BenefitAmount: 100000,
    EffectiveDate: "01/01/2021",
    PaidToDate: "01/01/2021",
    AppStatus: true,
    PolicyStatus: "Active",
    PolicyReason: true,
    PastDue: 19,
    DaysBeforePremium: 14,
    Action: "View",
  },
  {
    Id: 2,
    Verify: false,
    PolicyNumber: "GIW00982821",
    PolicyType: "Medicare",
    Carrier: "AIG",
    Product: "AIG Life",
    ProductType: "Level2",
    Premium: 1000,
    BenefitAmount: 100000,
    EffectiveDate: "01/01/2021",
    PaidToDate: "01/01/2021",
    AppStatus: true,
    PolicyStatus: "InActive",
    PolicyReason: true,
    PastDue: 18,
    DaysBeforePremium: 24,
    Action: "View",
  },
  {
    Id: 3,
    Verify: true,
    PolicyNumber: "GIW00982821",
    PolicyType: "Life Insurance",
    Carrier: "AIG",
    Product: "AIG Life",
    ProductType: "Level3",
    Premium: 1000,
    BenefitAmount: 100000,
    EffectiveDate: "01/01/2021",
    PaidToDate: "01/01/2021",
    AppStatus: true,
    PolicyStatus: "Active",
    PolicyReason: true,
    PastDue: 21,
    DaysBeforePremium: 10,
    Action: "View",
  },
  {
    Id: 4,
    Verify: false,
    PolicyNumber: "GIW00982821",
    PolicyType: "Medicare",
    Carrier: "AIG",
    Product: "AIG Life",
    ProductType: "Level4",
    Premium: 1000,
    BenefitAmount: 100000,
    EffectiveDate: "01/01/2021",
    PaidToDate: "01/01/2021",
    AppStatus: true,
    PolicyStatus: "Future",
    PolicyReason: true,
    PastDue: 20,
    DaysBeforePremium: 26,
    Action: "View",
  },
];
const PolicyDetailsTable = () => {
  const [viewOpen, setViewOpen] = useState(false);
  const handleViewOpen = () => setViewOpen(true);
  const handleViewClose = () => setViewOpen(false);
  const [editOpen, setEditOpen] = useState(false);
  const handleEditOpen = () => setEditOpen(true);
  const handleEditClose = () => setEditOpen(false);

  const handleDelete = () => {
    Swal.fire({
      title: "Are you sure?",
      text: "You won't be able to revert this!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Yes, delete it!",
    }).then((result) => {
      if (result.isConfirmed) {
        Swal.fire({
          title: "Deleted!",
          text: "Your file has been deleted.",
          icon: "success",
        });
      }
    });
  };
  return (
    <>
      <table className="table mb-3">
        <thead>
          <tr>
            <th className="text-center">#</th>
            <th className="text-uppercase text-center">Verified</th>
            <th className="text-uppercase">Policy number</th>
            <th className="text-uppercase">Policy Type</th>
            <th className="text-uppercase">Carrier</th>
            <th className="text-uppercase">Product</th>
            <th className="text-uppercase">Product Type</th>
            <th className="text-uppercase">Premium</th>
            <th className="text-uppercase">Benefit Amount</th>
            <th className="text-uppercase">Effective Date</th>
            <th className="text-uppercase">Paid To Date</th>
            <th className="text-uppercase">App. Status</th>
            <th className="text-uppercase">Policy Status</th>
            <th className="text-uppercase">Policy Reason</th>
            <th className="text-uppercase">Past due</th>
            <th className="text-uppercase">Days Before Premium</th>
            <th className="text-uppercase">Action</th>
          </tr>
        </thead>
        <tbody>
          {PolicyDetailData?.length !== 0 ? (
            PolicyDetailData?.map((res, i) => {
              return (
                <tr key={i}>
                  <td className="text-center">{res.Id}</td>
                  <td className="text-center">
                    {res.Verify === true ? (
                      <img src="../../../../public/Images/verify.svg" alt="" />
                    ) : (
                      "-"
                    )}
                  </td>
                  <td>{res.PolicyNumber}</td>
                  <td>{res.PolicyType}</td>
                  <td>{res.Carrier}</td>
                  <td>{res.Product}</td>
                  <td>{res.ProductType}</td>
                  <td>${res.Premium}</td>
                  <td>${res.BenefitAmount}</td>
                  <td>{res.EffectiveDate}</td>
                  <td>{res.PaidToDate}</td>
                  <td>{res.AppStatus === true ? "Approved" : "Pending"}</td>
                  <td>
                    <span
                      className={` ${
                        res.PolicyStatus === "Active"
                          ? "badge text-bg-success fw-normal"
                          : res.PolicyStatus === "InActive"
                          ? "badge text-bg-danger fw-normal"
                          : "badge text-bg-warning fw-normal"
                      }`}
                    >
                      {res.PolicyStatus}
                    </span>
                  </td>
                  <td>{res.PolicyReason === true ? "Current" : "Pending"}</td>
                  <td>{res.PastDue}days</td>
                  <td>{res.DaysBeforePremium}days</td>
                  <td>
                    <ButtonToolbar>
                      <Button onClick={handleViewOpen}>
                        <Eye size="16" color="#344054" variant="Outline" />
                      </Button>
                      <Button onClick={handleEditOpen}>
                        <Edit2 size="16" color="#344054" variant="Outline" />
                      </Button>
                      <Button onClick={handleDelete}>
                        <Trash size="16" color="#344054" variant="Outline" />
                      </Button>
                    </ButtonToolbar>
                  </td>
                </tr>
              );
            })
          ) : (
            <tr>
              <td colSpan={17} className="text-center bg-primary text-light">
                No Data Found
              </td>
            </tr>
          )}
        </tbody>
      </table>
      <ViewModal open={viewOpen} handleViewClose={handleViewClose} />
      <EditModal open={editOpen} handleEditClose={handleEditClose} />
    </>
  );
};

export default PolicyDetailsTable;
