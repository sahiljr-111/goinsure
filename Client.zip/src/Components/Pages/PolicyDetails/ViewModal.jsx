import React from "react";
import { Modal, Toggle, Button, ButtonToolbar, Placeholder } from "rsuite";

const ViewModal = ({ open, handleViewClose }) => {
  return (
    <>
      <Modal open={open} onClose={handleViewClose}>
        <Modal.Header>
          <Modal.Title className="modal-title">View Document</Modal.Title>
        </Modal.Header>
        <Modal.Body>{/* <Placeholder.Paragraph rows={80} /> */}</Modal.Body>
        {/* <Modal.Footer>
          <Button onClick={handleClose} appearance="primary">
            Ok
          </Button>
          <Button onClick={handleClose} appearance="subtle">
            Cancel
          </Button>
        </Modal.Footer> */}
      </Modal>
    </>
  );
};

export default ViewModal;
