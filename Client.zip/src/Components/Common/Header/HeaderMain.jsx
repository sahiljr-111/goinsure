import React from "react";
import { Form, Button, List, Avatar } from "rsuite";
import {
  ArrowRight2,
  SearchNormal1,
  NotificationBing,
  Headphone,
  Sun1,
  ArrowDown2,
} from "iconsax-react";

const HeaderMain = () => {
  return (
    <>
      <div className="gw-head-titleuser-wrap d-flex align-items-center flex-wrap justify-content-between px-4">
        <a
          href="#"
          className="gw-humburger transition-ease d-none position-absolute text-decoration-none"
        >
          <ArrowRight2 color="#fff" variant="Outline" size={20} />
        </a>
        <div className="gw-headtitlebar d-flex align-items-center justify-content-center flex-grow-1">
          <Form>
            <Form.Group controlId="" className="form-group mb-0 w-100 d-flex">
              <Form.Control
                className="rounded-3 search-control"
                placeholder="Global search"
                name="globalsearch"
              />
              <Button className="search-btn-cont">
                <SearchNormal1 color="#667085" variant="Outline" size={16} />
              </Button>
            </Form.Group>
          </Form>
        </div>
        <div className="gw-head-notificationuser">
          <List className="gw-notificationuser-list d-flex flex-wrap align-items-center p-0 m-0 gap-3 gap-lg-4 ">
            <List.Item className="nav-item gw-head-dropdown p-0">
              <a className="nav-link position-relative" href="#">
                <Headphone color="#667085" variant="Outline" />
              </a>
            </List.Item>
            <List.Item className="nav-item gw-head-dropdown p-0">
              <a className="nav-link position-relative" href="#">
                <Sun1 color="#667085" variant="Outline" />
              </a>
            </List.Item>
            <List.Item className="nav-item gw-head-dropdown p-0">
              <a className="nav-link position-relative" href="#">
                <NotificationBing color="#667085" variant="Outline" />
              </a>
            </List.Item>
            <List.Item className="nav-item headuser_dropdown gw-head-dropdown p-0 userprofile_dropdown ps-4">
              <div className="d-flex gap-2 align-items-center">
                <Avatar
                  circle
                  src="https://i.pravatar.cc/150?u=git@rsutiejs.com"
                />
                <ArrowDown2 size="16" color="#667085" variant="Outline" />
              </div>
              {/* <Dropdown>
							<Dropdown.Item panel style={{ padding: 10, width: 160 }}>
							<p>Signed in as</p>
							<strong>Tony</strong>
							</Dropdown.Item>
							<Dropdown.Separator />
							<Dropdown.Item>Your profile</Dropdown.Item>
							<Dropdown.Item>Your stars</Dropdown.Item>
							<Dropdown.Item>Your Gists</Dropdown.Item>
							<Dropdown.Separator />
							<Dropdown.Item>Help</Dropdown.Item>
							<Dropdown.Item>Settings</Dropdown.Item>
							<Dropdown.Item>Sign out</Dropdown.Item>
						</Dropdown> */}
            </List.Item>
          </List>
        </div>
      </div>
    </>
  );
};

export default HeaderMain;
