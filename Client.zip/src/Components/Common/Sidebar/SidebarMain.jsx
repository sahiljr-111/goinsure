import React from "react";
import { Sidebar, Sidenav, Navbar, Nav } from "rsuite";
import Logo from "../../../assets/images/logo.png";
import LogoIcon from "../../../assets/images/logo-icon.png";
import {
  Home2,
  Notification,
  Setting2,
  Calendar1,
  LogoutCurve,
  ArrowSwapHorizontal,
} from "iconsax-react";

const headerStyles = {
  height: 60,
  overflow: "hidden",
};
const NavToggle = ({ expand, onChange }) => {
  return (
    <Navbar appearance="subtle" className="nav-toggle gw-logout-navbar">
      <Nav className="logout-btn">
        <Nav.Item
          eventKey="1"
          active
          icon={<LogoutCurve className="rs-icon" variant="Outline" />}
        >
          Logout
        </Nav.Item>
      </Nav>
      <Nav className="gw-pinsidebar">
        <Nav.Item onClick={onChange}>
          {expand ? (
            <ArrowSwapHorizontal color="#fff" variant="Outline" />
          ) : (
            <ArrowSwapHorizontal color="#fff" variant="Outline" />
          )}
        </Nav.Item>
      </Nav>
    </Navbar>
  );
};
const SidebarMain = ({ expand, setExpand }) => {
  return (
    <Sidebar
      className={`gw-sidebar${!expand ? " active" : ""}`}
      style={{ display: "flex", flexDirection: "column" }}
      width={expand ? 256 : 60}
      collapsible
    >
      <Sidenav.Header>
        <div style={headerStyles} className="gw-logo-site">
          <img src={Logo} alt="GoinsureWise" className="desktop-logo" />
          <img src={LogoIcon} alt="GoinsureWise" className="toggle-logo" />
        </div>
      </Sidenav.Header>
      <Sidenav
        className="scrollbar position-relative navslidebar-div"
        expanded={expand}
        appearance="subtle"
      >
        <Sidenav.Body>
          <h5 className="mb-2 text-uppercase ps-3">Main</h5>
          <Nav>
            <Nav.Item
              eventKey="1"
              active
              icon={<Home2 className="rs-icon" variant="Outline" />}
            >
              Dashboard
            </Nav.Item>
            <Nav.Item
              eventKey="2"
              icon={<Notification className="rs-icon" variant="Outline" />}
            >
              Notification
            </Nav.Item>
            <Nav.Menu
              eventKey="3"
              trigger="hover"
              title="Settings"
              icon={<Setting2 className="rs-icon" variant="Outline" />}
              placement="rightStart"
            >
              <Nav.Item eventKey="3-1">Earnings</Nav.Item>
              <Nav.Item eventKey="3-2">Refunds</Nav.Item>
              <Nav.Item eventKey="3-3">Declines</Nav.Item>
              <Nav.Item eventKey="3-4">Payouts</Nav.Item>
            </Nav.Menu>
            <Nav.Menu
              eventKey="4"
              trigger="hover"
              title="Schedules"
              icon={<Calendar1 className="rs-icon" variant="Outline" />}
              placement="rightStart"
            >
              <Nav.Item eventKey="4-1">Applications</Nav.Item>
              <Nav.Item eventKey="4-2">Websites</Nav.Item>
              <Nav.Item eventKey="4-3">Channels</Nav.Item>
              <Nav.Item eventKey="4-4">Tags</Nav.Item>
              <Nav.Item eventKey="4-5">Versions</Nav.Item>
            </Nav.Menu>
          </Nav>
        </Sidenav.Body>
      </Sidenav>
      <NavToggle expand={expand} onChange={() => setExpand(!expand)} />
    </Sidebar>
  );
};

export default SidebarMain;
